#include "telegram_logic.h"
#include <iostream>

int main() {
    int m = -1;
    if (!telegram_logic::ParseDailyTimeMinutes(L"08:05", m) || m != 485) return 1;
    if (telegram_logic::ParseDailyTimeMinutes(L"24:00", m)) return 2;
    if (telegram_logic::ParseDailyTimeMinutes(L"8:05", m)) return 3;
    if (telegram_logic::ClampSummaryIntervalMinutes(1) != 5) return 4;
    if (telegram_logic::ClampSummaryIntervalMinutes(2000) != 1440) return 5;
    if (telegram_logic::ClampWorldFlowTimeoutSeconds(1) != 30) return 6;
    if (!telegram_logic::LooksLikeBotToken(L"123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ")) return 7;
    if (!telegram_logic::LooksLikeTelegramChatId(L"-100123456789")) return 8;
    if (!telegram_logic::LooksLikeTelegramChatId(L"@channel")) return 9;
    const std::string sample = R"({"ok":true,"result":[{"message":{"chat":{"id":123,"type":"private"}}},{"message":{"chat":{"id":-100456,"type":"supergroup"}}}]})";
    if (!telegram_logic::BotApiOk(sample)) return 10;
    if (telegram_logic::FindLatestChatIdInJson(sample) != "-100456") return 11;
    std::cout << "telegram_logic_tests PASS\n";
    return 0;
}
