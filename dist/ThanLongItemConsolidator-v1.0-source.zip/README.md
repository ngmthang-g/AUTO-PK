# Thần Long Item Consolidator v1.0


## v1.0 — Ghép nguyên tab TELEGRAM từ donor v0.6 vào nền v0.6.2.0

- Giữ nguyên nền **AUTO + AUTO PK v0.6.2.0**; không thay controller bằng donor.
- Thêm tab **TELEGRAM** theo UI/hành vi của donor v0.6: Bot Token DPAPI, Chat ID, test bot, lấy Chat ID, gửi thử, báo cáo ngay, event toggles, lịch định kỳ/mốc cố định và Telegram log.
- Telegram là **observer/output-only**: worker HTTPS riêng, không gọi Bridge action, không click, không StartPath/StopPath, không tham gia scheduler AUTO/Auto PK.
- Remap ID nội bộ Telegram từ donor `400–448` sang `500–548` vì Auto PK đang dùng `400–431`; đây là thay đổi chống xung đột event, không đổi giao diện/hành vi.
- Tab order: **AUTO → AUTO PK → TELEGRAM → GIỚI THIỆU**. Chuyển AUTO↔TELEGRAM chỉ đổi UI; AUTO đang chạy vẫn tiếp tục. Chuyển vào AUTO PK vẫn giữ nguyên fail-safe STOP của v0.6.2.0.
- Các hook Telegram chỉ quan sát sự kiện đã có: Death/Revive, SELL complete, Trade complete, Client Freeze/Recover, FIFO, Lâu Lan confirm, WorldFlow timeout, F4/tool state và summary.
- Protocol EXE/DLL giữ `0x00010620` vì không sửa bridge/protocol.
- Quy ước version từ đây: **1.0, 1.1, 1.2...**

## v0.6.2.0 — Auto PK / Bộ điều phối chiến tranh

- Thêm tab **AUTO PK** độc lập cạnh AUTO. Mỗi lần vào tab này tool mặc định **STOP**, hủy workflow AUTO/trade đang chạy và cảnh báo để hai scheduler không tranh quyền điều khiển. Rời tab AUTO PK cũng dừng scheduler PK.
- Dùng lại hidden `ClickInternalPoint → InputSyncManager.TryClickUI → EndUIDrag`, snapshot `LifeState/AutoFight/AutoPath/Map/X/Y`, Travel Guard và cơ chế attach hiện có; không thêm đường click chuột Windows.
- 6 bước mặc định: **Trị Liệu**, **Auto buff**, **Tụ điểm phụ**, **Lao vào PK**, và 2 bước **Tùy chọn**. Bước có thể bật/tắt và kéo-thả đổi thứ tự.
- Mỗi bước có `delay`, `repeat`; mỗi click ẩn có mô tả, pha, `delay`, `repeat`, nút F8 capture, TEST, thêm/xóa/lên/xuống.
- Trị liệu dùng semantic callback UI với **Đỗ Thanh Đằng ResID 339**: ClickNPC → Trị liệu → Xác nhận → Ta biết rồi → đóng UI. Tọa độ thế giới được GET từ acc đang chọn vì donor không chứa tọa độ world đáng tin cậy.
- Bước Lao PK chạy barrier nhóm: tất cả hoàn tất click **BẬT PK** → tất cả Travel Guard/AutoPath tới tọa PK chính → tất cả chạy click **AUTO PK** → chỉ hoàn tất khi snapshot xác nhận `AutoFight=ON`. Không cho AutoPath và AutoFight chạy chồng nhau.
- Life Guard tùy chọn: nếu một acc chết, toàn nhóm giữ barrier; acc chết được gọi semantic Revive theo nhịp giới hạn. Khi toàn nhóm sống lại, chuỗi PK chạy lại từ bước đầu.
- Protocol EXE/DLL: `0x00010620`.

## v0.6.1.9 — P3 post-WORLD-FLOW recovery + roadmap UI

- Fix deadlock thật trong `HandleFightClicks`: sau 2 lần AUTO→Đánh quái fail, code cũ reset `lastAutoFightCheckTick` mỗi tick ~250 ms nên chu kỳ 60 giây không bao giờ tới hạn.
- Thêm `fightRetryWaitTick` riêng: neo đúng một lần, đếm lùi 60 giây, sau đó reset 2 attempts và tự cấp lại AUTO→Đánh quái nếu AutoFight vẫn OFF.
- Giữ nguyên timing click đã chạy ổn: AUTO→choice 500 ms; verify AutoFight 1.5 s. Không tăng delay mù.
- AutoFight recheck vốn đã là 60 giây. Check tọa độ train giảm từ 180 giây xuống 60 giây theo yêu cầu.
- Tab GIỚI THIỆU thêm heading lớn `CÁC TÍNH NĂNG SẮP RA MẮT` và vùng cuộn chứa đầy đủ roadmap do user cung cấp.
- Protocol EXE/DLL: `0x00010619`.


## v0.6.1.8 — scoped maintenance: route ownership, M87, dead code, trade lock

- **Mục 2 — route ownership completion:** `crossMapRouteArmed/crossMapRouteMoved/crossMapSeenAutoPath` vẫn được giữ xuyên map trung gian để P1 Lâu Lan hoạt động, nhưng được clear đúng lúc route thực sự hoàn tất: đã ở trong tolerance đích, `AutoPath OFF`, đã xuống ngựa. Điều này ngăn P3 Train bị khóa bởi ownership cũ sau khi đã tới bãi/NPC/TỌA GD.
- **Mục 5 — Map 87:** guard Địa Phủ chỉ proactive khi workflow hiện tại có destination thật nằm **ngoài M87**. Train/đích nằm trong M87 không còn bị M87 guard tự tắt Fight. Mọi `Mount/StartPath` vẫn đi qua Travel Guard chung nên safety không giảm.
- **Mục 7 — dead-code cleanup:** xóa 5 helper không caller (`ActiveSellClickSequenceAccount`, `ClickSlotNow`, ba `RunPriority*Pass`) và 4 state không reader (`suppressRouteSinceTick`, `trainRecoveryTick`, `priorityAutoReason`, `sellTriggeredByFullBag`).
- **Mục 8 — trade lock cleanup:** xóa toàn bộ `Acquire/ReleaseTradeWorkflowLock*` no-op và callsite. `tradeTxn_ + tradeHeld` là lớp serialization nghiệp vụ duy nhất.
- Giữ nguyên v0.6.1.7 runtime-successful `AUTO → 500 ms → DỪNG AUTO 2`, FIFO, SELL, revive, per-client priority và hidden InputSync.
- Protocol EXE/DLL: `0x00010618`.


## v0.6.1.7 — AUTO → DỪNG AUTO 2 hidden sequence fix

- Runtime evidence from dồn đồ: MAIN/CON entering TỌA GD all failed `DỪNG AUTO 2` with `InputSyncManager raycast không bắt được UI`.
- Root cause: v0.6.1.4 simplified Stop to a direct `DỪNG AUTO 2` point even though that choice lives inside the AUTO menu. v0.5 correctly used `AUTO → wait → DỪNG AUTO 2`.
- Fix: one P3 Stop request now owns `AUTO → 500 ms → DỪNG AUTO 2`, both phases via `ClickInternalPoint → TryClickUI → EndUIDrag`. Completion is published only after click 2.
- Travel Guard still verifies authoritative `AutoFight OFF`; Stop #1 → Stop #2 → AUTO→ĐÁNH QUÁI reset → repeat is unchanged at the business layer.
- No physical mouse input is reintroduced. FIFO/tradeHeld/SELL/per-client scheduling remain unchanged.
- Protocol EXE/DLL: `0x00010617`.

> **Residual scheduler limitation:** v0.6.1.6 removes logical cross-window input locks, but `BridgeClient::Call()` is still synchronous on the controller thread. A single Bridge timeout can therefore delay the next scheduler iteration for its bounded timeout. This is no longer mouse contention, but it is not yet a true per-PID asynchronous worker architecture. Do not claim full timing independence until Bridge calls are moved to per-client workers/mailboxes.

## v0.6.1.6 — Per-client cleanup + Movement Guard

- Xóa toàn bộ global hidden-input owner/busy/sequence lease còn sót từ kiến trúc click vật lý. SELL, Train, Revive, XN và các client không liên quan không còn nhường nhau một tài nguyên input chung.
- Trade giữ thứ tự MAIN↔CON bằng `tradeTxn_`/`tradeHeld` nghiệp vụ, không dùng input lease. SELL của PID khác không làm trade dừng.
- REC chỉ tạm giữ acc đang capture; REC trade giữ đúng MAIN + CON đang capture. Các acc còn lại vẫn chạy.
- Priority runtime chuyển sang cục bộ theo từng PID: P1 XN → P2 Đầu thai → P3 AUTO trong chính acc đó; không còn global mouse barrier.
- **Invariant mới:** cả `Action::Mount` và `Action::StartPath` đều phải qua `EnsureAutoFightOffForTravel()`. AutoFight không authoritative hoặc còn ON → không được lên ngựa/AutoPath. Recovery giữ nguyên DỪNG #1 → DỪNG #2 → AUTO→ĐÁNH QUÁI reset → lặp.
- `Client Freeze`, F4 global pause, FIFO trade, death lifecycle, route ownership reset và AutoPath/Fight invariant giữ nguyên.
- Protocol EXE/DLL: `0x00010616`.


Nền phát triển trực tiếp: source v0.5.0 do người dùng cung cấp. Source v0.8.4 chỉ là donor để nghiên cứu cơ chế callback UI nội bộ; không ghép nguyên remote worker của donor.

## Tải bản Windows x64

- Current test target: **v0.6.1.9** — fixes the exhausted P3 retry deadlock after WORLD FLOW and adds the requested roadmap UI.
- Windows MSVC x64 CI: run **#423** (`32450581703`) PASS verifier, Release build and all **9 native self-test groups**, including the new AutoFight retry timer test.
- Source: branch `codex/v0.6.1.9-p3-retry-about-roadmap`.
- CI artifact ID `9435533249`; artifact digest `sha256:e2e2ecfb82df15b75492b0ae38210986dbd26b3edb9213d1dab3adf3dc83707f`.
- EXE SHA-256 `913d8fa075a8a695f0c3ed095a60dd7b05a3672dc00fcc7b41a686946241527c`; DLL SHA-256 `786ac8136721b0700c587d616fcb512b8f8439966eea0ca8c6b977e712238658`.
- Luôn giữ EXE cùng thư mục với `ThanLongCleanRouteBridge.dll`; protocol `0x00010619` cố ý từ chối DLL/EXE lệch version.
- **Runtime v0.6.1.9 chưa được gọi PASS** cho tới khi test thực chiến xác nhận CON sau WORLD FLOW đếm đủ retry và tự bật AutoFight trở lại.

## Hidden trade + AutoPath invariant v0.6.1.5

- Xóa hoàn toàn đường tự động `SetForegroundWindow → SetCursorPos → SendInput`; F8/REC chỉ còn ghi thao tác tay để cấu hình tọa độ.
- Mọi dòng giao dịch MAIN/CON được scale + normalize rồi gửi `ClickInternalPoint` tới đúng PID/window thread. Bridge thực hiện `TryClickUI → EndUIDrag` và fail-closed nếu raycast/drag lifecycle sai.
- Sequence lease chỉ giữ thứ tự nghiệp vụ; nó không sở hữu con trỏ Windows. Delay/repeat/group/FIFO và `FreeBagSpace` verify cuối pass được giữ nguyên.
- Mọi `StartPath` vẫn phải qua Travel Guard: DỪNG lần 1 → verify; DỪNG lần 2 → verify; nếu vẫn ON thì `AUTO → ĐÁNH QUÁI` một lần để đồng bộ rồi lặp DỪNG.
- Thêm invariant runtime: nếu snapshot từng thấy `AutoPath ON + AutoFight ON`, tool dừng path ngay, chạy lại Travel Guard và chỉ cho route resume sau khi thấy cả hai OFF.
- Một request bật Đánh quái dù đã xếp hàng cũng bị kiểm tra lại ngay trước từng dispatch; AutoPath chưa đọc được hoặc đang ON thì request bị hủy, không được dùng state cũ để bật AutoFight.
- Mailbox P3 gắn owner riêng cho Train, Travel Guard và Mount Recovery; workflow mới không thể nhận nhầm kết quả `Attack` còn sót của workflow cũ.

## Hotfix AUTO point sequence v0.6.1.4

- F8 chỉ ghi tọa độ tương đối theo client game; F8 không tự click và không lấy pointer UI.
- Bridge có command dùng chung `ClickInternalPoint`: đổi điểm sang Unity screen rồi gọi đủ `TryClickUI(0, point) → EndUIDrag(point)`.
- Một request bật Train chạy đúng thứ tự: điểm `AUTO` (click 1) → chờ 500 ms bằng state machine → điểm `ĐÁNH QUÁI` (click 2) → chờ snapshot `AutoFight ON`.
- Travel Guard/Dừng dùng điểm `DỪNG AUTO 2` và chỉ cho route chạy khi snapshot xác nhận `AutoFight OFF`.
- Nút TEST của ba dòng phát riêng đúng điểm F8 tương ứng để kiểm tra tọa độ trước khi bật nhiều account.
- Không foreground, không `SetCursorPos`, không `SendInput`; click trả OK vẫn chưa phải thành công nghiệp vụ nếu state AutoFight chưa đổi.

## Hotfix click item v0.6.1.3

- Log v0.6.1.2 `geometry=149` chứng minh resolver đã hoạt động, nhưng ô item không phải một `UIButton/UIRect` callback nằm dưới tọa độ; vì vậy cách dò 149 control không thể bấm ô đó.
- Repo dữ liệu client hiện tại chứng minh `InputSyncManager` có đúng chuỗi input UI của game. Một click hoàn chỉnh là `TryClickUI(0, point)` (nhấn trái) rồi `EndUIDrag(point)` (nhả/click), không phải gọi riêng `TryClickUI`.
- Bước item mới phát đúng cặp nhấn/nhả qua Unity EventSystem trên game thread. Nó không foreground, không `SetCursorPos`, không `SendInput` và không dùng chuột Windows.
- Trước nhấn phải không có `_uiDragging`; sau nhấn phải raycast trúng và tạo drag state; sau nhả state phải sạch. Nếu pha nhả lỗi, Bridge chỉ hủy drag do chính lượt đó tạo rồi dừng fail-closed.
- Tọa độ vẫn lấy từ dòng click đã gán; nên đặt ở tâm ô trang bị thứ 2 sau khi đã mở tab Trang bị.

## Hotfix resolver Unity geometry v0.6.1.2

- Log v0.6.1.1 chứng minh Bridge chưa hề dùng tọa độ hoặc callback item: nó dừng khi tìm class geometry.
- v0.6.1.1 sai ở giả định mọi class đều thuộc `UnityEngine.CoreModule`.
- v0.6.1.2 tìm riêng từng class qua `CoreModule`, `UIModule` và `UnityEngine.dll`. `RectTransformUtility` ưu tiên UIModule.
- Nếu vẫn thiếu, log mới nêu chính xác class nào thiếu và assembly nào thực sự mở được.
- Không đổi cách chọn dòng: chuỗi 6 click vẫn lấy dòng số 5; `6/6` trong log cũ là sáu lần retry callback, không phải dòng số 6.

## Logic ô trang bị cố định được giữ từ v0.5

- Chuỗi đang tốt `ClickNPC → shop → Bán vật phẩm → Bán nhanh → Trang bị` giữ nguyên.
- Chỉ bước item tay nải đổi: Bridge dùng tọa độ đã lấy để phát một click UI nội bộ của chính client. Không foreground, không `SendInput`, không di chuyển chuột.
- Profile v0.5 đủ 5 dòng dùng dòng 5. Nếu profile chỉ còn một dòng thì dùng chính dòng đó; với 2–4 dòng dùng dòng cuối.
- Vòng bán đầu gọi ô cố định 90 lần. Sau khi đóng UI và `FreeBagSpace` ổn định 1,5 giây, vòng bán sau dùng đúng số ô trống đã học, tối đa 90. Giá trị học chỉ sống trong phiên chạy tool như v0.5.
- Delay của dòng tọa độ vẫn là delay giữa từng callback. Cột `Lặp` cũ không quyết định vòng đầu trong hotfix này vì yêu cầu đã cố định là 90.
- Nên lấy F8 tại tâm ô trang bị thứ 2 sau khi đã mở đúng tab Trang bị. Từ v0.6.1.5, `TEST DÒNG`, chuỗi AUTO BÁN và chuỗi giao dịch đều dùng đường callback/InputSync nội bộ.

## Sửa lỗi resolver v0.6.1

- Basic discovery chỉ cần `UIObject.instances` và ít nhất một control class. `UIButton`/`UIToggle` không còn bị chặn vì thiếu Lua Executor.
- Namespace cũ vẫn là đường nhanh; nếu client đặt lớp ở namespace khác, Bridge quét metadata có giới hạn và chỉ nhận UIObject/Button/Toggle/Rect có đúng field/method cần dùng.
- `UIRectTransform` mới tải `MonoBehaviourExecutor` khi chính nó được chọn.
- AUTO Lua mới tải thêm `LuaSystemAPI_GUI`, `System.Object` và Executor.
- Executor được thử nhiều namespace, sau đó quét metadata theo tên lớp và bắt buộc có đúng `get_Instance()` + `ExecuteScriptFunction(3)`.
- Nếu vẫn lỗi, log trả chính xác component thiếu thay vì gộp bảy dependency thành một câu.

## Thay đổi chính

- `Xác nhận ra map`: vẫn giữ nguyên điều kiện watchdog Lâu Lan của v0.5, nhưng Bridge tìm nút đồng ý duy nhất bên trong `MessageBox` rồi gọi callback nội bộ. Không foreground cửa sổ, không di chuyển chuột.
- `Đầu thai`: Bridge đọc lại `IsDeath=true`, tìm đúng control `Đầu thai` và gọi `UIButton.HandleClickEvent()`.
- `AUTO → Đánh quái`: active P3 dùng hai điểm InputSync cấu hình; `Dừng AUTO` dùng điểm InputSync thứ ba. Controller vẫn xác minh kết quả bằng snapshot AutoFight authoritative.
- `Tự bán đồ`: các stage semantic qua Trang bị giữ nguyên; v0.6.1.3 gọi lặp một ô trang bị do tọa độ cấu hình chọn, rồi đóng UI và xác minh `FreeBagSpace` ổn định.
- Chuỗi giao dịch MAIN/CON dùng tọa độ cấu hình nhưng phát qua InputSync nội bộ; không foreground và không chiếm chuột Windows.

## Kiến trúc tích hợp

v0.6.1.5 tiếp tục dùng Bridge DLL `WH_GETMESSAGE` vốn có của v0.5. Mỗi Bridge request chỉ phát một click hoàn chỉnh trên đúng message thread; controller tách repeat/delay thành scheduler ticks và không chạy vòng lặp dài trong hook. Không thêm `CreateRemoteThread` hoặc worker IL2CPP thứ hai.

Điểm XN/Đầu thai vẫn chỉ để tương thích vì hai action này dùng semantic callback. Ba điểm AUTO/Đánh quái/Dừng đã active lại qua InputSync. Editor macro bán vẫn cung cấp tọa độ/delay ô item; bốn click mở shop cũ không quay lại active runtime.

## Build và kiểm tra

Workflow Windows x64 chạy:

1. `tools/verify_v0615_logic.py`.
2. Build controller + Bridge bằng MSVC.
3. Route, rotation, trade coordinator self-tests.
4. Background UI scoring self-test.
5. Fixed-slot selection/adaptive-count self-test.
6. Unity geometry resolver search-order self-test.
7. Internal UI press/release dispatch-plan self-test.
8. Travel Guard + AutoPath/AutoFight invariant self-test.

Windows MSVC x64 [run 307](https://github.com/ngmthang-g/TEST-chuc-nang-than-long-2/actions/runs/32427510483) PASS toàn bộ các bước trên. Artifact ID `9427940998`, GitHub digest `sha256:dd21bf0d3f96a4e8b37d623cf5c54beb5a4e8f067033f5fb42f4261596e7988a`. Build pass không được suy thành live-client pass.

Đọc [DONOR_0.8.4_BACKGROUND_ACTION_ANALYSIS.md](DONOR_0.8.4_BACKGROUND_ACTION_ANALYSIS.md) để xem diễn giải chi tiết donor 0.8.4 và quyết định chuyển đổi.
