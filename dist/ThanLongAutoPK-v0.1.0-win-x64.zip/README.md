# Thần Long AUTO-PK

Controller tối giản tách từ nền v0.2.7-R3. Repo nghiên cứu client: `ngmthang-g/clinent-game-than-long-DATA-2222`.

## Phạm vi giữ lại

- Bộ điều phối đa client / checkbox start-stop.
- F4 global pause/resume; vẫn đọc snapshot khi pause.
- Fail-closed bridge + freeze khi client/map chưa ổn định.
- Central mouse arbiter: một PID giữ chuột; acc khác FREEZE mutable action. Chuỗi trị liệu/buff/PK giữ sequence lease tới khi xong.
- Tự hồi sinh bằng tọa click đã gán.
- Tự xác nhận ra map theo semantic `confirmUiVisible` của bridge R3.
- Lâu Lan `MapID=5`, Đỗ Thanh Đằng `NPC ID=339` hard-code; người dùng chỉ gán vị trí đứng gần NPC.
- Sau mở NPC: 4 click trị liệu; tùy chọn 4 click buff.
- Tập kết 2 điểm chung: PHỤ -> barrier tất cả acc -> CHÍNH.
- Tới điểm chính: 5 click Auto PK.

## Đã loại bỏ hoàn toàn khỏi controller mới

- Dồn đồ / MAIN-CON.
- Chuỗi giao dịch.
- Chuỗi bán đồ / Auto Sell.
- Rotation bãi, bag-full workflow và editor macro cũ.

## Thiết lập lần đầu

1. Quét client, chọn một acc.
2. Đứng gần Đỗ Thanh Đằng ở Lâu Lan và bấm **LẤY VỊ TRÍ NPC TỪ ACC**.
3. Đứng tại điểm PHỤ và CHÍNH của map PK để lấy hai tọa độ.
4. Trong bảng click, lần lượt chọn dòng, bấm **LẤY ĐIỂM...**, đưa chuột vào đúng nút game rồi nhấn F8.
5. Bật/tắt **BUFF SAU TRỊ LIỆU**. Nếu bật phải gán đủ Buff 1..4.
6. Tick các acc và bấm **BẮT ĐẦU ACC TICK**.

F4 tạm dừng toàn bộ action nhưng vẫn quan sát snapshot.
