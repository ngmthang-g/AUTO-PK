# AUTO-PK Project Knowledge

## Version v0.1.0

Base controller architecture: ThanLongItemConsolidator v0.2.7-R3. Runtime bridge remains the R3 `ThanLongCleanRouteBridge` protocol v1.5.2.

Verified client identities from the research repository:
- Lâu Lan: MapID `5`.
- Đỗ Thanh Đằng: NPC ID `339`, ResName `LangZhong1`.
- NPC interaction donor: `GoToNPC(mapID,npcID) -> GetNPCPosition -> GoTo -> ClickNPC`.

Design decisions:
- Do not carry trade/sell/consolidation code into AUTO-PK.
- Keep one mutable action owner per PID and one central real-mouse lease across PIDs.
- Read-only snapshot polling continues while other accounts are frozen by the mouse lease.
- Death is authoritative from `ValidLifeState/dead`; revive click repeats fail-closed every 5s while dead.
- Confirm is only clicked when the R3 semantic `ValidConfirmUi/confirmUiVisible` observer says it is visible.
- Healer opening uses bridge `ClickNpc(339)`; the four treatment UI clicks remain user-captured because exact runtime dialog selection IDs are not proven.
- Rally barrier requires every running account to be alive and physically within tolerance of the shared staging point before release to the main point.
- On main point each account receives the shared five-click Auto-PK sequence under the mouse lease.
