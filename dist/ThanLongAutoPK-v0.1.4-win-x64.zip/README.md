# Thần Long AUTO-PK v0.1.4

Controller AUTO-PK tách từ nền v0.2.7-R3. Repo nghiên cứu client chỉ dùng để tra cứu: `ngmthang-g/clinent-game-than-long-DATA-2222`.

## Chu trình v0.1.4

### 1. Hồi sinh có điều kiện
- Chỉ khi snapshot authoritative báo `DEAD=1` mới chạy dòng **HỒI SINH / ĐẦU THAI**.
- Nếu acc đang ALIVE thì bỏ qua bước hồi sinh và đi tiếp ngay.
- Sau click không coi click-success là sống lại; chờ `dead=0` + map/spawn ổn định.

### 2. Recovery tại NPC Đỗ Thanh Đằng
Sau khi sống, tool đi Lâu Lan `MapID=5`, tới vị trí đứng gần **Đỗ Thanh Đằng / NPC ID 339**, mở NPC bằng bridge rồi chạy các dòng đã tick theo đúng thứ tự:

1. TRỊ LIỆU
2. XÁC NHẬN TRỊ LIỆU 1
3. XÁC NHẬN TRỊ LIỆU 2
4. AUTO (TRƯỚC BUFF)
5. BUFF — chỉ chạy khi toggle Buff bật
6. TẮT BẢNG
7. AUTO (SAU TẮT BẢNG)
8. DỪNG

Mỗi dòng có checkbox, Delay riêng và Repeat riêng.

### 3. Tọa PHỤ: PK + Liên minh chạy NGAY
Sau recovery, acc đi **TỌA PHỤ**.

Ngay khi vào sai số TỌA PHỤ, acc chạy:
1. **PK TẠI TỌA PHỤ**
2. **LIÊN MINH TẠI TỌA PHỤ**

Không chờ tới tọa CHÍNH mới click hai dòng này.

Acc chỉ thành `PHỤ READY` khi hai dòng đã tick và toàn bộ repeat của chúng chạy xong.

### 4. Barrier nhiều acc
Barrier chỉ PASS khi mọi acc đang RUN:
- còn sống,
- đang ở TỌA PHỤ,
- đã hoàn tất PK + Liên minh tại PHỤ.

Sau đó tất cả mới cùng chạy sang **TỌA CHÍNH**.

### 5. Smart XÁC NHẬN RA MAP
Confirm không chạy theo timer mù.

Tool chỉ cho phép click dòng **XÁC NHẬN RA MAP (SEMANTIC)** khi:
- cross-map route được chính tool khởi tạo;
- đã quan sát được AutoPath / Moving / map-transition thật;
- hành trình đã dừng trước khi tới MapID đích;
- snapshot có `ValidConfirmUi`;
- `confirmUiVisible == 1` — semantic `MessageBox` thật đang hiện.

Sau click:
- chờ MessageBox đóng;
- chờ MapID / MapReady / transition xác nhận đã qua map;
- timeout chỉ dùng để re-arm route, tuyệt đối không dùng làm bằng chứng để click Confirm.

Đây là invariant lấy từ donor v0.9.0 nhưng dùng observer semantic hiện tại của CleanRoute v1.5.2, không bê worker/thread cũ.

### 6. Tọa CHÍNH
Khi thật sự tới TỌA CHÍNH và MapID/MapReady/position đúng, chạy chuỗi:

1. **AUTO TẠI TỌA CHÍNH**
2. **PK TẠI TỌA CHÍNH**
3. **AUTO LẦN 2 TẠI TỌA CHÍNH**
4. **TRAIN TẠI TỌA CHÍNH**

Sau chuỗi, tool dùng `ValidAutoFight/autoFight` để xác minh AutoFight đang ON. Nếu vẫn OFF, tool giữ fail-closed và không tự toggle lặp mù.

## Bảng click
- Tất cả dòng mặc định tick.
- Bỏ tick dòng nào = skip dòng đó.
- Mỗi dòng lưu riêng: F8 coordinate, Delay 0..60000ms, Repeat 1..100, enabled.
- Buff còn có toggle tổng; toggle OFF chỉ bỏ riêng dòng BUFF.
- Chuỗi giữ global mouse lease; acc khác freeze mutable action nhưng snapshot vẫn đọc.

## Map profile
Mỗi profile lưu riêng:
- `StageMap + StageX + StageY` cho TỌA PHỤ;
- `MainMap + MainX + MainY` cho TỌA CHÍNH.

PHỤ và CHÍNH **có thể khác MapID**. Chọn profile trong combobox sẽ nạp lại cả hai map và tọa độ.

## Safety giữ nguyên
- F4 pause/resume toàn bộ mutable action; snapshot vẫn poll.
- Fail-closed khi state/observer không authoritative.
- Một mouse-owner tại một thời điểm.
- Không dùng blind periodic Confirm.
- Không mang trade/sell/consolidation vào AUTO-PK.


## v0.1.4 mouse lease invariant

Mouse ownership is per physical click only: acquire immediately before foreground/cursor/down/up, release immediately after mouse-up. Configured row delay and repeat waiting never hold the global mouse lease, so other running accounts may click during those waits.
