import importlib.util
import contextlib
import io
from pathlib import Path
import sys


sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v17_stock_sell", ROOT / "tools" / "verify_v17_stock_sell.py"
)
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


def rejected(action):
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            action()
    except SystemExit as error:
        assert error.code == 1
        return
    raise AssertionError("mutation escaped verifier")


def assert_direct_route_mutations_are_rejected():
    bridge = (ROOT / "src" / "bridge.cpp").read_bytes().decode("utf-8")
    direct = VERIFY.BASE.function_body(bridge, "DirectSellTest")
    VERIFY.verify_direct_body(direct)

    wrong_lookup = direct.replace(
        "FindCurrentStockSellRoot", 'FindUiByName("NPCShop_SellItemTab")', 1
    )
    rejected(lambda: VERIFY.verify_direct_body(wrong_lookup))

    ambiguous_execute = direct.replace(
        "ExecuteStockSellRequest", "ExecuteLuaOnObject", 1
    )
    rejected(lambda: VERIFY.verify_direct_body(ambiguous_execute))


def assert_resolver_mutation_is_rejected():
    bridge = (ROOT / "src" / "bridge.cpp").read_bytes().decode("utf-8")
    resolver = VERIFY.BASE.function_body(bridge, "FindCurrentStockSellRoot")
    VERIFY.verify_resolver_body(resolver)
    wrong_script = resolver.replace("NPCShop_SellItemTab", "NPCShop", 1)
    rejected(lambda: VERIFY.verify_resolver_body(wrong_script))
    wrong_activity = resolver.replace("get_ActiveInHierarchy", "get_Name", 1)
    rejected(lambda: VERIFY.verify_resolver_body(wrong_activity))


def assert_safety_helper_mutations_are_rejected():
    bridge = (ROOT / "src" / "bridge.cpp").read_bytes().decode("utf-8")
    belongs = VERIFY.BASE.function_body(bridge, "BelongsToCurrentShop")
    VERIFY.verify_belongs_body(belongs)
    foreign_is_accepted = belongs.replace("parent == npcShop", "parent != npcShop", 1)
    rejected(lambda: VERIFY.verify_belongs_body(foreign_is_accepted))

    selector = VERIFY.BASE.function_body(bridge, "FindUiObjectExecuteMethod")
    VERIFY.verify_execute_method_body(selector)
    wrong_first_parameter = selector.replace(
        "firstClass != g_ui.uiObject", "firstClass == g_ui.uiObject", 1
    )
    rejected(lambda: VERIFY.verify_execute_method_body(wrong_first_parameter))


def assert_release_test_guard_mutation_is_rejected():
    source = (ROOT / "src" / "direct_sell_logic_test.cpp").read_bytes().decode("utf-8")
    VERIFY.verify_direct_logic_test_source(source)
    disabled_in_release = source.replace("CHECK(", "assert(", 1)
    rejected(lambda: VERIFY.verify_direct_logic_test_source(disabled_in_release))

    cmake = (ROOT / "CMakeLists.txt").read_bytes().decode("utf-8")
    VERIFY.verify_release_test_config(cmake)
    ndebug_restored = cmake.replace("/UNDEBUG", "/DNDEBUG", 1)
    rejected(lambda: VERIFY.verify_release_test_config(ndebug_restored))


def assert_exact_instance_verification_mutation_is_rejected():
    controller = (ROOT / "src" / "controller.cpp").read_bytes().decode("utf-8")
    body = VERIFY.BASE.function_body(controller, "RunInventoryDirectSellTest")
    VERIFY.verify_controller_body(body)
    missing_fresh_scan = body.replace("scanSucceeded = ScanBagSemantic", "scanSucceeded = true", 1)
    rejected(lambda: VERIFY.verify_controller_body(missing_fresh_scan))


def assert_every_protected_definition_is_guarded():
    for relative, expected_by_name in [
        ("src/controller.cpp", VERIFY.BASE.PROTECTED_CONTROLLER),
        ("src/bridge.cpp", VERIFY.BASE.PROTECTED_BRIDGE),
    ]:
        source = (ROOT / relative).read_bytes().decode("utf-8")
        for name, expected in expected_by_name.items():
            assert VERIFY.BASE.function_sha(source, name) == expected
            original = VERIFY.BASE.function_body(source, name)
            mutated = original[:-1] + "\n/* v1.7 verifier mutation */\n}"
            mutated_source = source.replace(original, mutated, 1)
            mismatches = VERIFY.BASE.protected_mismatches(mutated_source, expected_by_name)
            assert name in mismatches, f"definition mutation escaped audit: {name}"


if __name__ == "__main__":
    assert_direct_route_mutations_are_rejected()
    assert_resolver_mutation_is_rejected()
    assert_safety_helper_mutations_are_rejected()
    assert_release_test_guard_mutation_is_rejected()
    assert_exact_instance_verification_mutation_is_rejected()
    assert_every_protected_definition_is_guarded()
    print("verify_v17_stock_sell self-test PASS")
