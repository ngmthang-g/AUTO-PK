from pathlib import Path
import importlib.util
import sys


sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v16_stock_sell", ROOT / "tools" / "verify_v16_stock_sell.py"
)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def text(relative):
    return (ROOT / relative).read_bytes().decode("utf-8")


def require(condition, message):
    if not condition:
        print("FAIL:", message)
        raise SystemExit(1)


def verify_direct_body(direct):
    for marker in [
        "FindFreshBagItem",
        "CanTestSell(item.sellable != 0, item.itemID)",
        "FindCurrentStockSellRoot",
        'g_api.string_new("RequestSellItem")',
        "ExecuteStockSellRequest",
        "ActionResult::ActionInvoked",
    ]:
        require(marker in direct, "DirectSellTest nested-root marker missing: " + marker)
    for forbidden in [
        'FindUiByName("NPCShop_SellItemTab"',
        "FindCurrentShopContext", "SendNetworkPacket", "BuildPayload", "200036",
        "SetCursorPos", "SendInput", "mouse_event", "WM_LBUTTONDOWN", "WM_LBUTTONUP",
        "PostMessage", "SendMessage", "InvokeControl", "InternalUiClick", "RunSellMacroClick",
    ]:
        require(forbidden not in direct, "DirectSellTest forbidden path present: " + forbidden)
    require(direct.count('g_api.string_new("RequestSellItem")') == 1,
            "DirectSellTest must create exactly one stock sell request")
    require(direct.count("ExecuteStockSellRequest(") == 1,
            "DirectSellTest must dispatch exactly once")


def verify_resolver_body(resolver):
    for marker in [
        'FindUiByName("NPCShop"',
        '"FindScriptUIRoots"',
        '"System.String"',
        'g_api.string_new("NPCShop_SellItemTab")',
        "ReadManagedPointerArray",
        'L"SellItemTab"',
        '"get_ActiveInHierarchy"',
        "BelongsToCurrentShop",
        "SelectStockSellRoot",
        "StockSellRootDecision::Unique",
    ]:
        require(marker in resolver, "nested sell-root resolver marker missing: " + marker)
    require(resolver.count('"get_ActiveInHierarchy"') == 2,
            "resolver must validate both NPCShop and nested-root activity")
    require("active != 0" in resolver,
            "nested sell-root activity must require a true value")
    require("selection.decision != direct_sell_logic::StockSellRootDecision::Unique" in resolver,
            "resolver must fail closed unless the candidate is unique")


def verify_belongs_body(belongs):
    for marker in [
        '"get_CoreParents"',
        "ReadManagedPointerArray(coreParents, parents, 64)",
        '"get_Parent"',
        "depth < 16",
        "std::find(seen.begin(), seen.end(), current)",
    ]:
        require(marker in belongs, "shop-ancestry marker missing: " + marker)
    require(belongs.count("parent == npcShop") == 2,
            "shop ancestry must compare both CoreParents and Parent chain by identity")
    require("parent != npcShop" not in belongs,
            "shop ancestry must not accept a foreign parent")


def verify_execute_method_body(selector):
    for marker in [
        "class_get_methods",
        "method_get_name",
        '"ExecuteScriptFunction"',
        "method_get_param_count(method) != 3",
        "StaticMethod(method)",
        "class_from_type(firstType)",
        "firstClass != g_ui.uiObject",
        'ParamType(method, 1, "System.String")',
        'ParamType(method, 2, "System.Object[]")',
        "if (match && match != method)",
        "return match",
    ]:
        require(marker in selector, "exact UIObject overload marker missing: " + marker)
    require("firstClass == g_ui.uiObject" not in selector,
            "overload selector must reject a non-UIObject first parameter")


def verify_direct_logic_test_source(source):
    require("#define CHECK(expression)" in source and "return 1;" in source,
            "direct sell logic tests need an always-active failure path")
    require("<cassert>" not in source and "assert(" not in source,
            "direct sell logic tests must not compile away under Release/NDEBUG")
    for marker in [
        "CHECK(CanTestSell",
        "CHECK(!SelectedInstanceAbsentAfterScan",
        "StockSellRootDecision::Unique",
        "StockSellRootDecision::Missing",
        "StockSellRootDecision::Ambiguous",
        "const StockSellRootCandidate inactive",
        "const StockSellRootCandidate foreign",
    ]:
        require(marker in source, "direct sell logic test marker missing: " + marker)


def verify_release_test_config(cmake):
    require("foreach(t IN LISTS LOGIC_TEST_TARGETS)" in cmake,
            "Release assertion guard must cover every logic test target")
    require("target_compile_options(${t} PRIVATE /UNDEBUG)" in cmake,
            "MSVC Release tests must undefine NDEBUG")
    require("target_compile_options(${t} PRIVATE /DNDEBUG)" not in cmake,
            "logic tests must not restore NDEBUG")


def verify_controller_body(controller_test):
    for marker in [
        "selectedRow.item.sellable",
        "IsQuestFamily(selectedRow.item.itemID)",
        "Command::DirectSellTest",
        "attempt < 10",
        "scanSucceeded = ScanBagSemantic",
        "liveInstanceIDs.push_back(row.item.instanceID)",
        "SelectedInstanceAbsentAfterScan",
        "if (removed)",
        "T1 PASS: selected instance disappeared",
        "Legacy AUTO SELL is not changed",
    ]:
        require(marker in controller_test, "controller exact-instance marker missing: " + marker)
    for forbidden in [
        "NpcShopID=", "ShopID=", "SetCursorPos", "SendInput", "mouse_event",
        "SendNetworkPacket", "200036",
    ]:
        require(forbidden not in controller_test, "controller T1 forbidden path present: " + forbidden)
    require(controller_test.count("Command::DirectSellTest") == 1,
            "controller T1 must issue exactly one bridge command")
    scan_position = controller_test.index("scanSucceeded = ScanBagSemantic")
    exact_instance_position = controller_test.index("SelectedInstanceAbsentAfterScan")
    pass_position = controller_test.index("if (removed)")
    require(scan_position < exact_instance_position < pass_position,
            "T1 PASS must follow a successful fresh scan and exact-instance absence check")


def verify():
    bridge = text("src/bridge.cpp")
    controller = text("src/controller.cpp")
    protocol = text("src/protocol.h")
    cmake = text("CMakeLists.txt")
    resource = text("resources/app.rc")
    readme = text("README.md")
    changelog = text("CHANGELOG.md")

    direct = BASE.function_body(bridge, "DirectSellTest")
    verify_direct_body(direct)

    controller_test = BASE.function_body(controller, "RunInventoryDirectSellTest")
    verify_controller_body(controller_test)

    resolver = BASE.function_body(bridge, "FindCurrentStockSellRoot")
    verify_resolver_body(resolver)

    belongs = BASE.function_body(bridge, "BelongsToCurrentShop")
    verify_belongs_body(belongs)

    selector = BASE.function_body(bridge, "FindUiObjectExecuteMethod")
    verify_execute_method_body(selector)

    execute = BASE.function_body(bridge, "ExecuteStockSellRequest")
    for marker in ["FindUiObjectExecuteMethod", "InvokeVoid"]:
        require(marker in execute, "exact UIObject execution marker missing: " + marker)
    require("ExecuteLuaOnObject" not in execute,
            "T1 exact execution must not use the ambiguous shared overload resolver")

    verify_direct_logic_test_source(text("src/direct_sell_logic_test.cpp"))

    require("VERSION 1.7.0" in cmake, "CMake version missing")
    require(text("VERSION.txt").strip() == "1.7", "VERSION must be 1.7")
    require("FILEVERSION 1,7,0,0" in resource, "resource numeric version missing")
    require("ThanLongItemConsolidator_v1.7.exe" in resource, "resource filename missing")
    require("kProtocolVersion = 0x00010625u" in protocol, "protocol version missing")
    require("DirectSellTest = 22" in protocol, "DirectSellTest command changed")
    require("verify_v17_stock_sell" in cmake, "v1.7 verifier is not registered with CTest")
    verify_release_test_config(cmake)
    for label in [
        "Item Consolidator v1.7",
        "Item Consolidator • v1.7",
        "Thần Long v1.7 • LỌC ĐỒ TAY NẢI",
    ]:
        require(label in controller, "controller v1.7 label missing: " + label)
    require("## v1.7" in readme, "README v1.7 section missing")
    require("## v1.7" in changelog, "CHANGELOG v1.7 entry missing")
    require("RUNTIME UNTESTED" in changelog.split("## v1.6", 1)[0],
            "v1.7 runtime status must remain explicit")

    for name in BASE.protected_mismatches(controller, BASE.PROTECTED_CONTROLLER):
        require(False, "protected controller changed: " + name)
    for name in BASE.protected_mismatches(bridge, BASE.PROTECTED_BRIDGE):
        require(False, "protected bridge changed: " + name)

    print("PASS: v1.7 nested stock RequestSellItem T1 scope + protected-function audit")


if __name__ == "__main__":
    verify()
