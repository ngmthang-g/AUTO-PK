#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace direct_sell_logic {

enum class StockSellRootDecision {
    Missing,
    Unique,
    Ambiguous,
};

struct StockSellRootCandidate {
    bool objectPresent = false;
    bool nameMatches = false;
    bool activeInHierarchy = false;
    bool belongsToCurrentShop = false;
};

struct StockSellRootSelection {
    StockSellRootDecision decision = StockSellRootDecision::Missing;
    std::size_t index = 0;
};

inline StockSellRootSelection SelectStockSellRoot(
    const StockSellRootCandidate* candidates,
    std::size_t count) {
    StockSellRootSelection result{};
    for (std::size_t i = 0; candidates && i < count; ++i) {
        const StockSellRootCandidate& candidate = candidates[i];
        if (!candidate.objectPresent || !candidate.nameMatches ||
            !candidate.activeInHierarchy || !candidate.belongsToCurrentShop) {
            continue;
        }
        if (result.decision == StockSellRootDecision::Unique) {
            result.decision = StockSellRootDecision::Ambiguous;
            return result;
        }
        result.decision = StockSellRootDecision::Unique;
        result.index = i;
    }
    return result;
}

inline bool IsQuestFamily(std::int32_t itemID) {
    return itemID >= 40000000 && itemID < 50000000;
}

inline bool CanTestSell(bool sellable, std::int32_t itemID) {
    return sellable && itemID > 0 && !IsQuestFamily(itemID);
}

inline bool SelectedInstanceAbsentAfterScan(
    bool scanSucceeded,
    std::int64_t selectedInstanceID,
    const std::vector<std::int64_t>& liveInstanceIDs) {
    return scanSucceeded && selectedInstanceID > 0 &&
           std::find(liveInstanceIDs.begin(), liveInstanceIDs.end(), selectedInstanceID) ==
               liveInstanceIDs.end();
}

} // namespace direct_sell_logic
