# Thần Long AUTO-PK v0.1.2

Controller AUTO-PK tách từ nền v0.2.7-R3. Repo nghiên cứu client chỉ dùng để tra cứu: `ngmthang-g/clinent-game-than-long-DATA-2222`.

## Logic chạy đã chốt

1. Bấm **BẮT ĐẦU ACC TICK**.
2. Mỗi acc được đọc state sống/chết:
   - `DEAD=1` -> chạy dòng **HỒI SINH / ĐẦU THAI**.
   - đang **ALIVE** -> bỏ qua hoàn toàn bước hồi sinh và đi tiếp chu trình ngay.
3. Sau khi sống: Confirm ra map chỉ chạy khi bridge báo `confirmUiVisible`.
4. Đi Lâu Lan `MapID=5` -> vị trí đứng gần **Đỗ Thanh Đằng, NPC ID=339** -> mở NPC -> chạy các dòng TRỊ LIỆU đã tick; nếu bật Buff thì chạy các dòng BUFF đã tick.
5. Đi **TỌA PHỤ** của map PK.
6. Ngay tại TỌA PHỤ, acc tự chạy các dòng **AUTO PK 1..5** đã tick để bật PK. Mỗi dòng có **Delay riêng + số lần lặp riêng**.
7. Acc nào chạy xong chuỗi PK ở TỌA PHỤ chuyển thành `PK READY` và đứng chờ.
8. Barrier chỉ mở khi **toàn bộ acc đang chạy** đều: còn sống + đang trong sai số TỌA PHỤ + `PK READY`.
9. Khi barrier PASS, tất cả cùng đi **TỌA CHÍNH**. Auto PK đã được bật từ TỌA PHỤ nên tới CHÍNH chỉ giữ trạng thái PK và đánh.
10. Nếu sau đó có acc chết, acc đó hồi sinh -> trị liệu -> tập kết PHỤ; coordinator kéo chu kỳ tập kết mới cho các acc đang chạy.

## Bảng click

- Mọi dòng mặc định **được tick**.
- Bỏ tick dòng nào = state machine bỏ qua dòng đó.
- Mỗi dòng lưu riêng:
  - tọa click F8,
  - Delay (0..60000 ms),
  - Lặp (1..100 lần),
  - Bật/Bỏ qua.
- Repeat của Hồi sinh/Xác nhận vẫn bị khóa bởi state thật: nếu đã ALIVE hoặc Confirm UI biến mất thì không click mù thêm.
- Các chuỗi Trị liệu/Buff/AUTO PK giữ mouse lease xuyên suốt; acc khác freeze mutable action nhưng vẫn đọc snapshot.

## Map profile

- Có thể gõ tên rồi bấm **LƯU MAP** để lưu nhiều bộ `MapID + TỌA PHỤ + TỌA CHÍNH`.
- Cuộn/chọn map cũ trong combobox sẽ nạp lại ngay tọa PHỤ và CHÍNH đã lưu.
- Có nút **XÓA MAP**.

## An toàn/coordinator giữ nguyên

- F4 global pause/resume; vẫn đọc snapshot khi pause.
- Fail-closed bridge + freeze khi client/map chưa ổn định.
- Central mouse arbiter: một PID giữ chuột tại một thời điểm.
- Không mang code dồn đồ, giao dịch, auto sell vào controller AUTO-PK.

## Thiết lập lần đầu

1. Quét client và chọn một acc.
2. Đứng gần Đỗ Thanh Đằng ở Lâu Lan, bấm **LẤY VỊ TRÍ NPC TỪ ACC**.
3. Đứng tại TỌA PHỤ và TỌA CHÍNH của map PK để lấy hai tọa độ, sau đó đặt tên và **LƯU MAP**.
4. Trong bảng click, chọn từng dòng cần dùng -> bấm **LẤY ĐIỂM...** -> đưa chuột vào đúng nút game -> F8.
5. Chỉnh Delay/Lặp của dòng đang chọn và bấm **LƯU DELAY / LẶP DÒNG**. Bỏ tick những bước muốn skip.
6. Bật/tắt **BUFF SAU TRỊ LIỆU**.
7. Tick các acc game và bấm **BẮT ĐẦU ACC TICK**.
