# AUTO-PK Project Knowledge

## Version v0.1.2

Base controller architecture: ThanLongItemConsolidator v0.2.7-R3. Runtime bridge remains the R3 `ThanLongCleanRouteBridge` protocol v1.5.2.

Verified client identities from the research repository:
- Lâu Lan: MapID `5`.
- Đỗ Thanh Đằng: NPC ID `339`, ResName `LangZhong1`.
- NPC interaction donor: `GoToNPC(mapID,npcID) -> GetNPCPosition -> GoTo -> ClickNPC`.

### State-machine rules

- START is an active cycle start, not monitor-only.
- If authoritative `ValidLifeState/dead == true`, only then may the Revive row run.
- If the account is already alive at START, Revive is skipped and the account enters the same post-alive recovery pipeline immediately.
- After alive: semantic Confirm -> healer -> treatment/buff -> staging point.
- At staging, run enabled AUTO-PK rows first. Account becomes `stagingPkReady` only after all enabled PK rows and their repeats complete.
- Barrier requires every running account to be alive, within staging tolerance, in WaitStaging, and `stagingPkReady=true`.
- Only after barrier PASS may all accounts route to the main point. No second blind PK click sequence is run at main; PK was enabled at staging.
- A later death starts a new recovery/rally generation.

### Click-row model

Each screen click row persists independently:
- `valid` + scaled point/base client size,
- `enabled` (default true),
- `delayMs` (0..60000),
- `repeat` (1..100).

Unchecked rows are skipped. Conditional rows (Revive/Confirm) stop clicking as soon as the authoritative condition disappears, even if configured repeat count was not exhausted. Treatment/Buff/PK sequences use their row-specific delay and repeat values while holding the global mouse lease.

### Map profiles

Multiple named map profiles persist `MapID + staging + main`. Selecting an existing combobox item immediately loads its saved coordinates into the active route fields.

### Safety / retained architecture

- Do not carry trade/sell/consolidation code into AUTO-PK.
- Keep one central real-mouse lease across PIDs.
- Read-only snapshot polling continues while other accounts are frozen by mouse lease.
- Confirm is gated by R3 `ValidConfirmUi/confirmUiVisible`.
- Healer opens via bridge `ClickNpc(339)`; treatment/buff UI remains user-captured.
- F4 freezes mutable actions while polling continues.
