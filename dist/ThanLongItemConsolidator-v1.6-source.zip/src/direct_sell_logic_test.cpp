#include "direct_sell_logic.h"
#include <cassert>
#include <cstdint>
#include <iostream>
#include <vector>

int main() {
    using namespace direct_sell_logic;
    assert(CanTestSell(true, 12345));
    assert(!CanTestSell(false, 12345));
    assert(!CanTestSell(true, 0));
    assert(!CanTestSell(true, -1));
    assert(!CanTestSell(true, 40000000));
    assert(!CanTestSell(true, 49999999));
    assert(CanTestSell(true, 50000000));

    const std::int64_t selected = 1087861151LL;
    assert(!SelectedInstanceAbsentAfterScan(false, selected, {}));
    assert(!SelectedInstanceAbsentAfterScan(true, 0, {}));
    assert(!SelectedInstanceAbsentAfterScan(true, selected, {selected, 77LL}));
    assert(SelectedInstanceAbsentAfterScan(true, selected, {77LL, 88LL}));
    assert(SelectedInstanceAbsentAfterScan(true, selected, {}));
    std::cout << "direct_sell_logic PASS\n";
    return 0;
}
