#pragma once
#include <algorithm>
#include <cstdint>
#include <vector>

namespace direct_sell_logic {

inline bool IsQuestFamily(std::int32_t itemID) {
    return itemID >= 40000000 && itemID < 50000000;
}

inline bool CanTestSell(bool sellable, std::int32_t itemID) {
    return sellable && itemID > 0 && !IsQuestFamily(itemID);
}

inline bool SelectedInstanceAbsentAfterScan(
    bool scanSucceeded,
    std::int64_t selectedInstanceID,
    const std::vector<std::int64_t>& liveInstanceIDs) {
    return scanSucceeded && selectedInstanceID > 0 &&
           std::find(liveInstanceIDs.begin(), liveInstanceIDs.end(), selectedInstanceID) ==
               liveInstanceIDs.end();
}

} // namespace direct_sell_logic
