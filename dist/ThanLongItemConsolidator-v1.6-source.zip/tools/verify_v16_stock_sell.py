from pathlib import Path
import hashlib
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


PROTECTED_CONTROLLER = {
    "RunSellMacroClick": "b0d49f5312ad377a9d3ff6c8ddd714b20e1d85ad25d0090deb58f8b99bd0ef4b",
    "TickAccount": "60ea192008f0b3f5d72082c1294ce7506b4acbde93fdea840f2b420b4705e3a5",
    "TickAutoPk": "273b857f99c16578be9ba89dabe4339c58b48eab426197a429b648bfea1f2dc7",
    "EnsureAutoFightOffForTravel": "b19f2e1c4bab708368ef523b18c88e9c820ed1c54f8a83d1e7e3061c296f9592",
    "HandleRobustTravel": "a6da039a4e90c1b6a558b1655dcb7020b5bb993e9b781f4836c145fb0cf468b9",
    "PriorityReviveClick": "7540ddcb94053c40f1005d9bed8b47c069d620e14e2461bc8643d9815fd3eb09",
    "PriorityAutoClick": "11d38a96dca96deef648b49986b00878cdd181a03f0878e98ebac5d883891c42",
    "ResetRuntimeForLifeBoundary": "a67af2fd13a5ccca237b56d2f1146a6f1fe02ce4820c495d7ff33aabbb3f1345",
    "BeginTrainRecovery": "fd0c37b8d633d5e609f443892e0ffbf3926a84390272b7cf5a897afb49cfdced",
    "HandleDeath": "5876babf991e5466679267e5f804ec1c54126a9932a789cc3c411acd6d5a0460",
    "AbortTrade": "c40db6ba2ffbfdd536ee84b5e4019ab7b1c63619c6abc2d97c7dece83c04beb3",
}
PROTECTED_BRIDGE = {
    "SellBagItem": "b2219eabe0b94917da72a9ba99eb1c24625fb766fff92bbf8b979b1ec28b21d8",
    "DropBagItem": "2839cbcb76e06279212897cc22b0c353c871e8591f94c03c0773d3147deb32ad",
    "ReadBagPage": "98a5686772c86a9fad98b3e2a5786c74ee9d60b108be7c533d438acceb2a22f6",
    "ReadBagObjects": "4d93a7ebbe03497219505603e9e42b7615c4aaee7bd2255464e3960b1b02bbfe",
    "SendNetworkPacket": "b72edb2b32973955dd3645a6e9af5da76df0ff3412514c6ac25950f55067838f",
}


def text(relative):
    return (ROOT / relative).read_bytes().decode("utf-8")


def fail(message):
    print("FAIL:", message)
    raise SystemExit(1)


def require(condition, message):
    if not condition:
        fail(message)


def definition_match(source, name):
    # A definition must begin like a C++ declaration. Calls such as
    # `if (!Name(...))` cannot satisfy this prefix or the terminal opening brace.
    pattern = re.compile(
        r"(?m)^[ \t]*"
        r"(?:(?:static|inline|constexpr|virtual|friend|explicit)\s+)*"
        r"(?:[A-Za-z_][\w:<>]*(?:\s*[*&])?\s+)+"
        r"(?P<name>" + re.escape(name) + r")\s*"
        r"\([^;{}]*\)\s*"
        r"(?:const\s*)?(?:noexcept(?:\s*\([^)]*\))?\s*)?\{"
    )
    matches = list(pattern.finditer(source))
    require(len(matches) == 1, f"expected one definition for {name}, found {len(matches)}")
    return matches[0]


def function_body(source, name):
    match = definition_match(source, name)
    begin = match.end() - 1
    depth = 0
    quote = None
    escaped = False
    line_comment = False
    block_comment = False
    index = begin
    while index < len(source):
        char = source[index]
        next_char = source[index + 1] if index + 1 < len(source) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
        elif block_comment:
            if char == "*" and next_char == "/":
                block_comment = False
                index += 1
        elif quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
        elif char == "/" and next_char == "/":
            line_comment = True
            index += 1
        elif char == "/" and next_char == "*":
            block_comment = True
            index += 1
        elif char in "\"'":
            quote = char
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[match.start("name"):index + 1]
        index += 1
    fail("unbalanced " + name)


def function_sha(source, name):
    return hashlib.sha256(function_body(source, name).encode()).hexdigest()


def protected_mismatches(source, expected_by_name):
    return [
        name for name, expected in expected_by_name.items()
        if function_sha(source, name) != expected
    ]


def verify():
    controller = text("src/controller.cpp")
    bridge = text("src/bridge.cpp")
    protocol = text("src/protocol.h")
    cmake = text("CMakeLists.txt")
    resource = text("resources/app.rc")
    readme = text("README.md")
    changelog = text("CHANGELOG.md")
    version = text("VERSION.txt").strip()

    require(version == "1.6", "VERSION must be 1.6")
    require("VERSION 1.6.0" in cmake, "CMake version missing")
    require("FILEVERSION 1,6,0,0" in resource, "resource numeric version missing")
    require("ThanLongItemConsolidator_v1.6.exe" in resource, "resource filename missing")
    require("kProtocolVersion = 0x00010624u" in protocol, "protocol version missing")
    require("DirectSellTest = 22" in protocol, "DirectSellTest command changed")
    require("include(CTest)" in cmake and "add_test(NAME ${t}" in cmake,
            "logic executables are not registered with CTest")
    require("verify_v16_stock_sell_self_test" in cmake,
            "verifier self-test is not registered with CTest")

    for label in [
        "Item Consolidator v1.6",
        "Item Consolidator • v1.6",
        "Thần Long v1.6 • LỌC ĐỒ TAY NẢI",
    ]:
        require(label in controller, "controller v1.6 label missing: " + label)
    require("v1.4" not in controller, "stale controller v1.4 label remains")

    direct = function_body(bridge, "DirectSellTest")
    for marker in [
        "FindFreshBagItem",
        "CanTestSell(item.sellable != 0, item.itemID)",
        'FindUiByName("NPCShop_SellItemTab"',
        'g_api.string_new("RequestSellItem")',
        "ExecuteLuaOnObject",
        "ActionResult::ActionInvoked",
        "stock RequestSellItem dispatched",
    ]:
        require(marker in direct, "DirectSellTest stock-route marker missing: " + marker)
    for forbidden in [
        "FindCurrentShopContext", "SendNetworkPacket", "BuildPayload", "200036",
        "SetCursorPos", "SendInput", "mouse_event", "WM_LBUTTONDOWN", "WM_LBUTTONUP",
        "PostMessage", "SendMessage", "InvokeControl", "InternalUiClick", "RunSellMacroClick",
    ]:
        require(forbidden not in direct, "DirectSellTest forbidden path present: " + forbidden)
    require(direct.count('g_api.string_new("RequestSellItem")') == 1,
            "DirectSellTest must create exactly one stock sell request")
    require(direct.count("ExecuteLuaOnObject(") == 1,
            "DirectSellTest must dispatch exactly once")

    controller_test = function_body(controller, "RunInventoryDirectSellTest")
    for marker in [
        "TEST STOCK SELL T1",
        "Command::DirectSellTest",
        "attempt < 10",
        "NPCShop_SellItemTab.RequestSellItem",
        "scanSucceeded = ScanBagSemantic",
        "liveInstanceIDs.push_back(row.item.instanceID)",
        "SelectedInstanceAbsentAfterScan",
        "T1 PASS: selected instance disappeared",
        "Legacy AUTO SELL is not changed",
    ]:
        require(marker in controller_test or marker in controller,
                "controller stock T1 marker missing: " + marker)
    for forbidden in ["NpcShopID=", "ShopID=", "SetCursorPos", "SendInput", "mouse_event"]:
        require(forbidden not in controller_test, "controller T1 forbidden path present: " + forbidden)
    require(controller_test.count("Command::DirectSellTest") == 1,
            "controller T1 must issue exactly one bridge command")
    scan_position = controller_test.index("scanSucceeded = ScanBagSemantic")
    exact_instance_position = controller_test.index("SelectedInstanceAbsentAfterScan")
    pass_position = controller_test.index("if (removed)")
    require(scan_position < exact_instance_position < pass_position,
            "T1 PASS is not gated by successful scan and exact-instance absence")

    require("## v1.6" in readme, "README v1.6 section missing")
    require("## v1.6" in changelog, "CHANGELOG v1.6 entry missing")
    require("RUNTIME UNTESTED" in changelog.split("## v1.5", 1)[0],
            "v1.6 runtime status must remain explicit")

    for name in protected_mismatches(controller, PROTECTED_CONTROLLER):
        fail("protected controller changed: " + name)
    for name in protected_mismatches(bridge, PROTECTED_BRIDGE):
        fail("protected bridge changed: " + name)

    print("PASS: v1.6 stock RequestSellItem T1 scope + protected-function audit")


if __name__ == "__main__":
    verify()
