from pathlib import Path
import hashlib,re,sys
ROOT=Path(__file__).resolve().parents[1]

def txt(rel): return (ROOT/rel).read_bytes().decode('utf-8')
def fail(msg): print('FAIL:',msg); sys.exit(1)
def need(ok,msg):
    if not ok: fail(msg)
def func(text,name):
    m=re.search(r'\b'+re.escape(name)+r'\s*\(',text)
    need(m is not None,'missing '+name)
    b=text.find('{',m.end()); need(b>=0,'no body '+name)
    depth=0; ins=None; esc=False
    for i in range(b,len(text)):
        c=text[i]
        if ins:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c==ins: ins=None
        else:
            if c in "\"'": ins=c
            elif c=='{': depth+=1
            elif c=='}':
                depth-=1
                if depth==0: return text[m.start():i+1]
    fail('unbalanced '+name)
def sha(text,name): return hashlib.sha256(func(text,name).encode()).hexdigest()
C=txt('src/controller.cpp'); B=txt('src/bridge.cpp'); P=txt('src/protocol.h'); CM=txt('CMakeLists.txt'); R=txt('resources/app.rc'); V=txt('VERSION.txt').strip()
need(V=='1.5','VERSION must be 1.5')
need('VERSION 1.5.0' in CM,'CMake version missing')
need('FILEVERSION 1,5,0,0' in R and 'ThanLongItemConsolidator_v1.5.exe' in R,'resource version missing')
need('kProtocolVersion = 0x00010623u' in P and 'DirectSellTest = 22' in P,'protocol/command missing')
for m in ['TEST DIRECT SELL T1 - 1 ITEM','Command::DirectSellTest','T1 VERIFY FAIL','T1 PASS: selected instance disappeared','Legacy AUTO SELL is not changed']:
    need(m in C,'controller T1 marker missing: '+m)
for m in ['bool DirectSellTest(','FindCurrentShopContext','SendNetworkPacket(c, 200036, payload','BuildPayload(item.instanceID, npcShopID, shopID)','packet not sent']:
    need(m in B,'bridge T1 marker missing: '+m)
need('direct_sell_logic_tests' in CM,'direct sell test target missing')
protectedC={
'RunSellMacroClick':'b0d49f5312ad377a9d3ff6c8ddd714b20e1d85ad25d0090deb58f8b99bd0ef4b',
'TickAccount':'60ea192008f0b3f5d72082c1294ce7506b4acbde93fdea840f2b420b4705e3a5',
'TickAutoPk':'273b857f99c16578be9ba89dabe4339c58b48eab426197a429b648bfea1f2dc7',
'EnsureAutoFightOffForTravel':'d45511f0ac256e954f113429bae509ff629c3eef8b20210acfb5ac3472503e38',
'HandleRobustTravel':'bb52cb528cf33f3ee8ed5febdb937a46de026c20d9d4ac939f7315c1f7053b61',
'PriorityReviveClick':'7540ddcb94053c40f1005d9bed8b47c069d620e14e2461bc8643d9815fd3eb09',
'PriorityAutoClick':'11d38a96dca96deef648b49986b00878cdd181a03f0878e98ebac5d883891c42',
'ResetRuntimeForLifeBoundary':'a67af2fd13a5ccca237b56d2f1146a6f1fe02ce4820c495d7ff33aabbb3f1345',
'BeginTrainRecovery':'ca91987e7f38d377c17d977fdacf91fddfc28aea55afaf25df8128c5df27adb3',
'HandleDeath':'5876babf991e5466679267e5f804ec1c54126a9932a789cc3c411acd6d5a0460',
'AbortTrade':'541fc139acebb036d35de37d5d4a3fef9d38cd386f4c59ba72a5889e17150dac'}
protectedB={
'SellBagItem':'b2219eabe0b94917da72a9ba99eb1c24625fb766fff92bbf8b979b1ec28b21d8',
'DropBagItem':'2839cbcb76e06279212897cc22b0c353c871e8591f94c03c0773d3147deb32ad',
'ReadBagPage':'98a5686772c86a9fad98b3e2a5786c74ee9d60b108be7c533d438acceb2a22f6',
'ReadBagObjects':'4d93a7ebbe03497219505603e9e42b7615c4aaee7bd2255464e3960b1b02bbfe',
'SendNetworkPacket':'b72edb2b32973955dd3645a6e9af5da76df0ff3412514c6ac25950f55067838f'}
for n,h in protectedC.items(): need(sha(C,n)==h,'protected controller changed: '+n)
for n,h in protectedB.items(): need(sha(B,n)==h,'protected bridge changed: '+n)
print('verify_v15_direct_sell PASS')
