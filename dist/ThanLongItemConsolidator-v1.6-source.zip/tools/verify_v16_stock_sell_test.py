import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v16_stock_sell", ROOT / "tools" / "verify_v16_stock_sell.py"
)
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


def assert_definition_lookup_skips_calls():
    source = """
void Caller() { ProtectedThing(1); }
bool ProtectedThing(int value) {
    return value > 0;
}
"""
    body = VERIFY.function_body(source, "ProtectedThing")
    assert body.startswith("ProtectedThing(int value)")
    assert "return value > 0" in body


def assert_every_protected_definition_is_guarded():
    for relative, expected_by_name in [
        ("src/controller.cpp", VERIFY.PROTECTED_CONTROLLER),
        ("src/bridge.cpp", VERIFY.PROTECTED_BRIDGE),
    ]:
        source = (ROOT / relative).read_bytes().decode("utf-8")
        for name, expected in expected_by_name.items():
            assert VERIFY.function_sha(source, name) == expected
            original = VERIFY.function_body(source, name)
            mutated = original[:-1] + "\n/* verifier mutation */\n}"
            mutated_source = source.replace(original, mutated, 1)
            mismatches = VERIFY.protected_mismatches(mutated_source, expected_by_name)
            assert name in mismatches, f"definition mutation escaped audit: {name}"


if __name__ == "__main__":
    assert_definition_lookup_skips_calls()
    assert_every_protected_definition_is_guarded()
    print("verify_v16_stock_sell self-test PASS")
