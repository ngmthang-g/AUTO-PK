# AUTO-PK Project Knowledge

## Version v0.1.5

Base is exactly AUTO-PK v0.1.4. Preserve its recovery, staging PK/Alliance, barrier, route, final Auto/PK/Auto/Train, F4, and click-only mouse lease behavior.

### User-requested v0.1.5 change: per-account periodic map Confirm
The previous semantic Smart Confirm is inactive in runtime flow.

For each game account/window store independently:
- Confirm click x/y and capture client width/height;
- `IntervalSec` (0..86400; START requires >0 when Confirm row master checkbox is enabled).

Persistence key prefers authoritative RoleID; if unavailable it falls back to a stable hash of character/window identity.

Runtime rule:
`START tick -> nextPeriodicConfirmTick = start + IntervalSec`.
When due, Confirm uses only time + saved per-account coordinate. It does not require `ValidConfirmUi`, `confirmUiVisible`, MessageBox, MapID, MapReady, moving, AutoPath, or any other snapshot proof.

After a successful physical click:
- release global mouse lease immediately after LEFTUP;
- set next due time to `now + IntervalSec`;
- configured waiting time never owns the mouse.

If a physical click fails, retry guard is 1 second; this is an input retry only, not UI recognition.

### Preserved state flow
`DEAD? -> revive if needed -> healer -> RecoveryClicks -> RouteStaging -> StageClicks(PK,Alliance) -> WaitStaging barrier -> RouteMain -> FinalClicks(Auto,PK,Auto,Train) -> VerifyFinalAuto -> Monitor`

### Preserved verified facts
- Lâu Lan = MapID 5.
- Đỗ Thanh Đằng = NPC ID 339 (`LangZhong1`).
- `ValidLifeState/dead` remains authoritative for revive logic.
- `ValidAutoFight/autoFight` remains final AutoFight observer.
- Stage and main keep independent MapID values.

### Mouse lease invariant
Mouse ownership is per physical click only: acquire immediately before foreground/cursor/down/up and release immediately after mouse-up. Row delay, repeat wait, and periodic Confirm interval never hold the lease.
