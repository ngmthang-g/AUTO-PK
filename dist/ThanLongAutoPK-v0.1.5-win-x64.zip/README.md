# Thần Long AUTO-PK v0.1.5

Base trực tiếp: AUTO-PK v0.1.4 click-only mouse lease. Toàn bộ flow hồi sinh / trị liệu / TỌA PHỤ / barrier / TỌA CHÍNH giữ nguyên; thay đổi duy nhất về nghiệp vụ là cơ chế **XÁC NHẬN RA MAP**.

## Chu trình giữ nguyên

1. DEAD mới chạy **HỒI SINH / ĐẦU THAI**; ALIVE bỏ qua hồi sinh.
2. Đi Lâu Lan M5 tới Đỗ Thanh Đằng NPC ID 339.
3. Recovery: TRỊ LIỆU → XN trị liệu 1 → XN trị liệu 2 → AUTO → BUFF? → TẮT BẢNG → AUTO → DỪNG.
4. Đi TỌA PHỤ; tới nơi chạy ngay **PK TẠI TỌA PHỤ → LIÊN MINH TẠI TỌA PHỤ**.
5. Barrier chỉ PASS khi mọi acc đang chạy đã PHỤ READY.
6. Tất cả route sang TỌA CHÍNH.
7. Tới CHÍNH chạy **AUTO → PK → AUTO → TRAIN** rồi xác minh AutoFight ON như v0.1.4.

## XÁC NHẬN RA MAP v0.1.5: timer riêng từng acc

Không dùng `ValidConfirmUi`, `confirmUiVisible`, MessageBox, MapID hay snapshot proof để quyết định click Confirm nữa.

Mỗi acc/cửa sổ có riêng:
- tọa độ nút **XÁC NHẬN RA MAP**;
- kích thước cửa sổ lúc gán để scale tọa độ;
- chu kỳ `IntervalSec` do người dùng tự nhập.

Khi START một acc có dòng **XÁC NHẬN RA MAP** đang tick:
- acc bắt đầu đếm timer riêng;
- sau đúng số giây đã cấu hình, tool đưa đúng cửa sổ lên foreground và click tọa Confirm riêng của acc đó;
- click xong nhả mouse lease ngay;
- timer của acc đó bắt đầu chu kỳ kế tiếp;
- acc khác có timer riêng và có thể click trong thời gian acc trước đang chờ chu kỳ.

Ví dụ: acc A = 3 giây, B = 5 giây, C = 8 giây. Ba timer hoạt động độc lập.

### Cách gán
1. Chọn đúng acc trong danh sách client.
2. Chọn dòng **XÁC NHẬN RA MAP (TIMER THEO ACC)**.
3. Bấm **LẤY ĐIỂM ĐANG CHỌN (F8)**.
4. Đưa chuột vào nút Xác nhận của đúng cửa sổ rồi nhấn F8.
5. Nhập số giây tại dòng **XN MAP ACC** phía trên và bấm **LƯU TIME XN ACC**.

Dòng XÁC NHẬN dùng checkbox hiện tại làm master enable. Khi master đang bật, mỗi acc được START phải có cả tọa Confirm riêng và số giây > 0.

## Các dòng click khác
- Vẫn dùng tọa độ dùng chung như v0.1.4.
- Checkbox / Delay / Repeat giữ nguyên.
- BUFF vẫn có toggle tổng riêng.

## Mouse lease giữ nguyên v0.1.4
Mouse ownership chỉ bao phủ click vật lý: foreground → cursor → LEFTDOWN → LEFTUP. Ngay sau mouse-up sẽ release lease. Delay/Repeat wait và thời gian chờ timer Confirm **không giữ chuột**, nên acc khác có thể click ngay.

## Map profile giữ nguyên
Mỗi profile lưu độc lập `StageMap/StageX/StageY` và `MainMap/MainX/MainY`. PHỤ và CHÍNH có thể khác MapID.

## F4 / safety giữ nguyên
- F4 pause/resume mutable action.
- Một mouse owner tại một thời điểm.
- Logic route/life/AutoFight khác vẫn dùng snapshot như v0.1.4.
- Riêng **XÁC NHẬN RA MAP** là periodic click theo timer người dùng yêu cầu, không dùng semantic Confirm observer.
