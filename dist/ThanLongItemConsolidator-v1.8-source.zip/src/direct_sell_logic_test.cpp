#include "direct_sell_logic.h"
#include <cstdint>
#include <iostream>
#include <vector>

#define CHECK(expression) \
    do { \
        if (!(expression)) { \
            std::cerr << "FAIL line " << __LINE__ << ": " #expression "\n"; \
            return 1; \
        } \
    } while (false)

int main() {
    using namespace direct_sell_logic;
    CHECK(CanTestSell(true, 12345));
    CHECK(!CanTestSell(false, 12345));
    CHECK(!CanTestSell(true, 0));
    CHECK(!CanTestSell(true, -1));
    CHECK(!CanTestSell(true, 40000000));
    CHECK(!CanTestSell(true, 49999999));
    CHECK(CanTestSell(true, 50000000));

    CHECK(CanTestDrop(true, 12345));
    CHECK(!CanTestDrop(false, 12345));
    CHECK(!CanTestDrop(true, 0));
    CHECK(!CanTestDrop(true, -1));
    CHECK(!CanTestDrop(true, 40000000));
    CHECK(!CanTestDrop(true, 49999999));
    CHECK(CanTestDrop(true, 50000000));

    const std::int64_t selected = 1087861151LL;
    CHECK(!SelectedInstanceAbsentAfterScan(false, selected, {}));
    CHECK(!SelectedInstanceAbsentAfterScan(true, 0, {}));
    CHECK(!SelectedInstanceAbsentAfterScan(true, selected, {selected, 77LL}));
    CHECK(SelectedInstanceAbsentAfterScan(true, selected, {77LL, 88LL}));
    CHECK(SelectedInstanceAbsentAfterScan(true, selected, {}));

    const StockSellRootCandidate currentShopRoots[] = {
        {true, false, true, true},
        {true, true, true, true},
        {true, true, true, false},
    };
    const StockSellRootSelection unique = SelectStockSellRoot(currentShopRoots, 3);
    CHECK(unique.decision == StockSellRootDecision::Unique);
    CHECK(unique.index == 1);

    const StockSellRootSelection missing = SelectStockSellRoot(nullptr, 0);
    CHECK(missing.decision == StockSellRootDecision::Missing);

    const StockSellRootCandidate inactive[] = {{true, true, false, true}};
    CHECK(SelectStockSellRoot(inactive, 1).decision == StockSellRootDecision::Missing);

    const StockSellRootCandidate foreign[] = {{true, true, true, false}};
    CHECK(SelectStockSellRoot(foreign, 1).decision == StockSellRootDecision::Missing);

    const StockSellRootCandidate ambiguous[] = {
        {true, true, true, true},
        {true, true, true, true},
    };
    CHECK(SelectStockSellRoot(ambiguous, 2).decision == StockSellRootDecision::Ambiguous);

    const StockShopRootCandidate shopRoots[] = {
        {true, false, true},
        {true, true, true},
        {true, true, false},
    };
    const StockSellRootSelection currentShop = SelectCurrentShopRoot(shopRoots, 3);
    CHECK(currentShop.decision == StockSellRootDecision::Unique);
    CHECK(currentShop.index == 1);

    CHECK(SelectCurrentShopRoot(nullptr, 0).decision == StockSellRootDecision::Missing);

    const StockShopRootCandidate inactiveShop[] = {{true, true, false}};
    CHECK(SelectCurrentShopRoot(inactiveShop, 1).decision == StockSellRootDecision::Missing);

    const StockShopRootCandidate ambiguousShops[] = {
        {true, true, true},
        {true, true, true},
    };
    CHECK(SelectCurrentShopRoot(ambiguousShops, 2).decision == StockSellRootDecision::Ambiguous);
    std::cout << "direct_sell_logic PASS\n";
    return 0;
}

#undef CHECK
