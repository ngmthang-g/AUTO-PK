import contextlib
import importlib.util
import io
from pathlib import Path
import sys


sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v18_stock_sell_drop", ROOT / "tools" / "verify_v18_stock_sell_drop.py"
)
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


def rejected(action):
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            action()
    except SystemExit as error:
        assert error.code == 1
        return
    raise AssertionError("mutation escaped verifier")


def assert_parent_resolver_mutations_are_rejected():
    bridge = (ROOT / "src" / "bridge.cpp").read_bytes().decode("utf-8")
    resolver = VERIFY.BASE.BASE.function_body(bridge, "FindCurrentStockSellRoot")
    VERIFY.verify_resolver_body(resolver)

    old_boundary = resolver.replace(
        'g_api.string_new("NPCShop")', 'FindUiByName("NPCShop")', 1
    )
    rejected(lambda: VERIFY.verify_resolver_body(old_boundary))

    wrong_parent_name = resolver.replace('L"NPCShop"', 'L"SellItemTab"', 1)
    rejected(lambda: VERIFY.verify_resolver_body(wrong_parent_name))

    missing_uniqueness = resolver.replace(
        "selection.decision != direct_sell_logic::StockSellRootDecision::Unique",
        "selection.decision == direct_sell_logic::StockSellRootDecision::Missing",
        1,
    )
    rejected(lambda: VERIFY.verify_resolver_body(missing_uniqueness))


def assert_drop_test_mutations_are_rejected():
    controller = (ROOT / "src" / "controller.cpp").read_bytes().decode("utf-8")
    drop_test = VERIFY.BASE.BASE.function_body(controller, "RunInventoryDirectDropTest")
    VERIFY.verify_drop_controller_body(drop_test)

    wrong_command = drop_test.replace("Command::DropBagItem", "Command::DirectSellTest", 1)
    rejected(lambda: VERIFY.verify_drop_controller_body(wrong_command))

    unsafe_default = drop_test.replace("MB_DEFBUTTON2", "MB_DEFBUTTON1", 1)
    rejected(lambda: VERIFY.verify_drop_controller_body(unsafe_default))

    missing_fresh_scan = drop_test.replace(
        "scanSucceeded = ScanBagSemantic", "scanSucceeded = true", 1
    )
    rejected(lambda: VERIFY.verify_drop_controller_body(missing_fresh_scan))


def assert_every_protected_definition_is_guarded():
    for relative, expected_by_name in [
        ("src/controller.cpp", VERIFY.BASE.BASE.PROTECTED_CONTROLLER),
        ("src/bridge.cpp", VERIFY.BASE.BASE.PROTECTED_BRIDGE),
    ]:
        source = (ROOT / relative).read_bytes().decode("utf-8")
        for name, expected in expected_by_name.items():
            assert VERIFY.BASE.BASE.function_sha(source, name) == expected
            original = VERIFY.BASE.BASE.function_body(source, name)
            mutated = original[:-1] + "\n/* v1.8 verifier mutation */\n}"
            mutated_source = source.replace(original, mutated, 1)
            mismatches = VERIFY.BASE.BASE.protected_mismatches(mutated_source, expected_by_name)
            assert name in mismatches, f"definition mutation escaped audit: {name}"


if __name__ == "__main__":
    assert_parent_resolver_mutations_are_rejected()
    assert_drop_test_mutations_are_rejected()
    assert_every_protected_definition_is_guarded()
    print("verify_v18_stock_sell_drop self-test PASS")
