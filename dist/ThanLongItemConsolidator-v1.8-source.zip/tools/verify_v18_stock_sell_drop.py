from pathlib import Path
import importlib.util
import sys


sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "verify_v17_stock_sell", ROOT / "tools" / "verify_v17_stock_sell.py"
)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)


def text(relative):
    return (ROOT / relative).read_bytes().decode("utf-8")


def require(condition, message):
    if not condition:
        print("FAIL:", message)
        raise SystemExit(1)


def verify_resolver_body(resolver):
    for marker in [
        '"FindScriptUIRoots"',
        'g_api.string_new("NPCShop")',
        'g_api.string_new("NPCShop_SellItemTab")',
        'L"NPCShop"',
        'L"SellItemTab"',
        '"get_ActiveInHierarchy"',
        "ReadManagedPointerArray",
        "SelectCurrentShopRoot",
        "SelectStockSellRoot",
        "BelongsToCurrentShop",
        "StockSellRootDecision::Unique",
    ]:
        require(marker in resolver, "v1.8 script-root resolver marker missing: " + marker)
    require('FindUiByName("NPCShop"' not in resolver,
            "v1.8 resolver must not use the failing LuaSystemAPI_GUI NPCShop lookup")
    require(resolver.count('g_api.string_new("NPCShop")') == 1,
            "v1.8 resolver must query the NPCShop script exactly once")
    require(resolver.count('g_api.string_new("NPCShop_SellItemTab")') == 1,
            "v1.8 resolver must query the sell-tab script exactly once")
    require(resolver.count("InvokeObjectArgs(findRoots") == 2,
            "v1.8 resolver must enumerate parent and child script roots exactly once each")
    require(resolver.count("selection.decision != direct_sell_logic::StockSellRootDecision::Unique") == 2,
            "v1.8 resolver must fail closed unless both parent and child roots are unique")


def verify_drop_controller_body(drop_test):
    for marker in [
        "selectedRow.item.throwable",
        "CanTestDrop",
        "MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2",
        "Command::DropBagItem",
        "attempt < 10",
        "scanSucceeded = ScanBagSemantic",
        "liveInstanceIDs.push_back(row.item.instanceID)",
        "SelectedInstanceAbsentAfterScan",
        "if (removed)",
        "DROP T1 PASS",
        "DROP T1 VERIFY FAIL",
        "RefreshInventoryBagList",
    ]:
        require(marker in drop_test, "manual drop T1 marker missing: " + marker)
    for forbidden in [
        "SendNetworkPacket", "100005", "SetCursorPos", "SendInput", "mouse_event",
        "DirectSellTest", "RunSellMacroClick",
    ]:
        require(forbidden not in drop_test, "manual drop T1 forbidden path present: " + forbidden)
    require(drop_test.count("Command::DropBagItem") == 1,
            "manual drop T1 must issue exactly one existing DropBagItem command")
    confirmation = drop_test.index("MessageBoxW")
    dispatch = drop_test.index("Command::DropBagItem")
    scan = drop_test.index("scanSucceeded = ScanBagSemantic")
    exact_instance = drop_test.index("SelectedInstanceAbsentAfterScan")
    passed = drop_test.index("if (removed)")
    require(confirmation < dispatch < scan < exact_instance < passed,
            "manual drop T1 must confirm, dispatch once, then verify exact-instance absence")


def verify_logic_test_source(source):
    BASE.verify_direct_logic_test_source(source)
    for marker in [
        "CHECK(CanTestDrop",
        "StockShopRootCandidate",
        "SelectCurrentShopRoot",
        "const StockShopRootCandidate inactiveShop",
        "const StockShopRootCandidate ambiguousShops",
    ]:
        require(marker in source, "v1.8 direct/drop logic test marker missing: " + marker)


def verify():
    bridge = text("src/bridge.cpp")
    controller = text("src/controller.cpp")
    protocol = text("src/protocol.h")
    cmake = text("CMakeLists.txt")
    resource = text("resources/app.rc")
    readme = text("README.md")
    changelog = text("CHANGELOG.md")

    direct = BASE.BASE.function_body(bridge, "DirectSellTest")
    BASE.verify_direct_body(direct)
    BASE.verify_controller_body(BASE.BASE.function_body(controller, "RunInventoryDirectSellTest"))
    verify_resolver_body(BASE.BASE.function_body(bridge, "FindCurrentStockSellRoot"))
    BASE.verify_belongs_body(BASE.BASE.function_body(bridge, "BelongsToCurrentShop"))
    BASE.verify_execute_method_body(BASE.BASE.function_body(bridge, "FindUiObjectExecuteMethod"))

    drop_test = BASE.BASE.function_body(controller, "RunInventoryDirectDropTest")
    verify_drop_controller_body(drop_test)
    verify_logic_test_source(text("src/direct_sell_logic_test.cpp"))
    BASE.verify_release_test_config(cmake)

    require("IDC_IF_DIRECT_DROP_TEST = 622" in controller,
            "manual drop T1 control ID is missing")
    require("TEST DROP T1 - 1 ITEM" in controller,
            "manual drop T1 button is missing")
    require("case IDC_IF_DIRECT_DROP_TEST: RunInventoryDirectDropTest();" in controller,
            "manual drop T1 click handler is missing")

    require("VERSION 1.8.0" in cmake, "CMake version missing")
    require(text("VERSION.txt").strip() == "1.8", "VERSION must be 1.8")
    require("FILEVERSION 1,8,0,0" in resource, "resource numeric version missing")
    require("ThanLongItemConsolidator_v1.8.exe" in resource, "resource filename missing")
    require("kProtocolVersion = 0x00010626u" in protocol, "protocol version missing")
    require("DirectSellTest = 22" in protocol, "DirectSellTest command changed")
    require("DropBagItem = 20" in protocol, "DropBagItem command changed")
    require("verify_v18_stock_sell_drop" in cmake, "v1.8 verifier is not registered with CTest")
    require("verify_v18_stock_sell_drop_self_test" in cmake,
            "v1.8 verifier self-test is not registered with CTest")
    for label in [
        "Item Consolidator v1.8",
        "Item Consolidator • v1.8",
        "Thần Long v1.8 • LỌC ĐỒ TAY NẢI",
    ]:
        require(label in controller, "controller v1.8 label missing: " + label)
    require("## v1.8" in readme, "README v1.8 section missing")
    require("## v1.8" in changelog, "CHANGELOG v1.8 entry missing")
    require("RUNTIME UNTESTED" in changelog.split("## v1.7", 1)[0],
            "v1.8 runtime status must remain explicit")

    for name in BASE.BASE.protected_mismatches(controller, BASE.BASE.PROTECTED_CONTROLLER):
        require(False, "protected controller changed: " + name)
    for name in BASE.BASE.protected_mismatches(bridge, BASE.BASE.PROTECTED_BRIDGE):
        require(False, "protected bridge changed: " + name)

    print("PASS: v1.8 script-root stock sell fix + manual drop T1 scope audit")


if __name__ == "__main__":
    verify()
