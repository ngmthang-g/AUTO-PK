#pragma once
#include <cstdint>
#include <string>

namespace direct_sell_logic {

inline bool IsQuestFamily(std::int32_t itemID) {
    return itemID >= 40000000 && itemID < 50000000;
}

inline bool CanTestSell(bool sellable, std::int32_t itemID, std::int64_t npcShopID, std::int64_t shopID) {
    return sellable && itemID > 0 && !IsQuestFamily(itemID) && npcShopID > 0 && shopID > 0;
}

inline std::string BuildPayload(std::int64_t instanceID, std::int64_t npcShopID, std::int64_t shopID) {
    return std::to_string(static_cast<long long>(instanceID)) + ":" +
           std::to_string(static_cast<long long>(npcShopID)) + ":" +
           std::to_string(static_cast<long long>(shopID));
}

} // namespace direct_sell_logic
