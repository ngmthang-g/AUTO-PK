#include "direct_sell_logic.h"
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    using namespace direct_sell_logic;
    assert(BuildPayload(123456789LL, 321, 7) == "123456789:321:7");
    assert(CanTestSell(true, 12345, 321, 7));
    assert(!CanTestSell(false, 12345, 321, 7));
    assert(!CanTestSell(true, 40000001, 321, 7));
    assert(!CanTestSell(true, 12345, 0, 7));
    assert(!CanTestSell(true, 12345, 321, 0));
    std::cout << "direct_sell_logic PASS\n";
    return 0;
}
